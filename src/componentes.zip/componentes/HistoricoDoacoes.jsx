import { FaArrowLeft, FaSearch, FaFilter, FaEye } from "react-icons/fa";

const HistoricoDoacoes = () => {
  const doacoes = [
    {
      id: 1,
      projeto: "Projeto Educação",
      valor: "R$ 500,00",
      data: "15/10/2025",
      status: "Confirmada",
      statusColor: "green",
    },
    {
      id: 2,
      projeto: "Saúde Comunitária",
      valor: "R$ 750,00",
      data: "10/10/2025",
      status: "Confirmada",
      statusColor: "green",
    },
    {
      id: 3,
      projeto: "Sustentabilidade",
      valor: "R$ 1.200,00",
      data: "05/10/2025",
      status: "Confirmada",
      statusColor: "green",
    },
    {
      id: 4,
      projeto: "Alimentação",
      valor: "R$ 300,00",
      data: "01/10/2025",
      status: "Processando",
      statusColor: "yellow",
    },
    {
      id: 5,
      projeto: "Habitação",
      valor: "R$ 2.000,00",
      data: "25/09/2025",
      status: "Confirmada",
      statusColor: "green",
    },
  ];

  return (
    <div className="w-full h-screen bg-gradient-to-br from-blue-50 to-purple-50">
      {/* Header */}
      <header className="bg-white shadow-md">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center gap-4">
          <button className="text-purple-600 hover:text-purple-700 transition">
            <FaArrowLeft className="text-2xl" />
          </button>
          <h1 className="text-2xl font-bold text-gray-800">Histórico de Doações</h1>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-6 py-8">
        {/* Filters Section */}
        <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
          <div className="flex flex-col md:flex-row gap-4">
            {/* Search Bar */}
            <div className="flex-1 relative">
              <FaSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Buscar por projeto..."
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
            </div>

            {/* Filter Button */}
            <button className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition">
              <FaFilter className="text-gray-600" />
              <span className="text-gray-700">Filtrar</span>
            </button>

            {/* Status Filter */}
            <select className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500">
              <option>Todos os status</option>
              <option>Confirmada</option>
              <option>Processando</option>
              <option>Cancelada</option>
            </select>
          </div>
        </div>

        {/* Donations Table */}
        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gradient-to-r from-purple-500 to-indigo-600 text-white">
                <tr>
                  <th className="px-6 py-4 text-left font-semibold">Projeto</th>
                  <th className="px-6 py-4 text-left font-semibold">Valor</th>
                  <th className="px-6 py-4 text-left font-semibold">Data</th>
                  <th className="px-6 py-4 text-left font-semibold">Status</th>
                  <th className="px-6 py-4 text-center font-semibold">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {doacoes.map((doacao) => (
                  <tr
                    key={doacao.id}
                    className="hover:bg-gray-50 transition cursor-pointer"
                  >
                    <td className="px-6 py-4">
                      <p className="font-semibold text-gray-800">{doacao.projeto}</p>
                    </td>
                    <td className="px-6 py-4">
                      <p className="font-bold text-gray-800">{doacao.valor}</p>
                    </td>
                    <td className="px-6 py-4">
                      <p className="text-gray-600">{doacao.data}</p>
                    </td>
                    <td className="px-6 py-4">
                      <span
                        className={`px-3 py-1 rounded-full text-sm font-semibold ${
                          doacao.statusColor === "green"
                            ? "bg-green-100 text-green-700"
                            : "bg-yellow-100 text-yellow-700"
                        }`}
                      >
                        {doacao.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-center">
                      <button className="text-purple-600 hover:text-purple-700 transition">
                        <FaEye className="text-lg" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          <div className="px-6 py-4 border-t border-gray-200 flex justify-between items-center">
            <p className="text-gray-600">Mostrando 1 a 5 de 12 doações</p>
            <div className="flex gap-2">
              <button className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition">
                Anterior
              </button>
              <button className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition">
                1
              </button>
              <button className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition">
                2
              </button>
              <button className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition">
                Próximo
              </button>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default HistoricoDoacoes;

