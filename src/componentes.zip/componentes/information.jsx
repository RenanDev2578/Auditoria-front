

function Information() {
    <h1>Information</h1>
}

export default Information;