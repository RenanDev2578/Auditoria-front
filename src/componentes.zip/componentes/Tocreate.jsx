function Tocreate() {
	  return <h1>CRIAR</h1>;
}

export default Tocreate;