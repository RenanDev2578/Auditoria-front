import { FaHeart, FaChartLine, FaGift, FaUser, FaSignOutAlt } from "react-icons/fa";

const DashboardDoador = () => {
  return (
    <div className="w-full h-screen bg-gradient-to-br from-blue-50 to-purple-50">
      {/* Header */}
      <header className="bg-white shadow-md">
        <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="bg-purple-600 p-2 rounded-lg">
              <FaHeart className="text-white text-2xl" />
            </div>
            <h1 className="text-2xl font-bold text-gray-800">Plataforma de Doações</h1>
          </div>
          <div className="flex items-center gap-4">
            <button className="flex items-center gap-2 text-gray-700 hover:text-purple-600 transition">
              <FaUser className="text-xl" />
              <span>Perfil</span>
            </button>
            <button className="text-gray-700 hover:text-red-600 transition">
              <FaSignOutAlt className="text-xl" />
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-6 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-gray-800 mb-2">
            Bem-vindo, João Silva!
          </h2>
          <p className="text-gray-600">
            Acompanhe o impacto de suas doações em tempo real
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {/* Card 1: Total Doado */}
          <div className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-gray-700 font-semibold">Total Doado</h3>
              <div className="bg-purple-100 p-3 rounded-lg">
                <FaGift className="text-purple-600 text-2xl" />
              </div>
            </div>
            <p className="text-3xl font-bold text-gray-800 mb-2">R$ 2.450,00</p>
            <p className="text-sm text-green-600">+12% este mês</p>
          </div>

          {/* Card 2: Doações Ativas */}
          <div className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-gray-700 font-semibold">Doações Ativas</h3>
              <div className="bg-blue-100 p-3 rounded-lg">
                <FaChartLine className="text-blue-600 text-2xl" />
              </div>
            </div>
            <p className="text-3xl font-bold text-gray-800 mb-2">8</p>
            <p className="text-sm text-gray-600">Em acompanhamento</p>
          </div>

          {/* Card 3: Impacto Social */}
          <div className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-gray-700 font-semibold">Impacto</h3>
              <div className="bg-green-100 p-3 rounded-lg">
                <FaHeart className="text-green-600 text-2xl" />
              </div>
            </div>
            <p className="text-3xl font-bold text-gray-800 mb-2">156</p>
            <p className="text-sm text-gray-600">Pessoas beneficiadas</p>
          </div>
        </div>

        {/* Recent Donations */}
        <div className="bg-white rounded-xl shadow-lg p-6">
          <h3 className="text-xl font-bold text-gray-800 mb-6">Doações Recentes</h3>
          <div className="space-y-4">
            {/* Donation Item 1 */}
            <div className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition cursor-pointer">
              <div className="flex items-center gap-4">
                <div className="bg-purple-100 p-3 rounded-lg">
                  <FaHeart className="text-purple-600" />
                </div>
                <div>
                  <p className="font-semibold text-gray-800">Projeto Educação</p>
                  <p className="text-sm text-gray-600">Doação em 15/10/2025</p>
                </div>
              </div>
              <div className="text-right">
                <p className="font-bold text-gray-800">R$ 500,00</p>
                <p className="text-sm text-green-600">Confirmada</p>
              </div>
            </div>

            {/* Donation Item 2 */}
            <div className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition cursor-pointer">
              <div className="flex items-center gap-4">
                <div className="bg-blue-100 p-3 rounded-lg">
                  <FaHeart className="text-blue-600" />
                </div>
                <div>
                  <p className="font-semibold text-gray-800">Saúde Comunitária</p>
                  <p className="text-sm text-gray-600">Doação em 10/10/2025</p>
                </div>
              </div>
              <div className="text-right">
                <p className="font-bold text-gray-800">R$ 750,00</p>
                <p className="text-sm text-green-600">Confirmada</p>
              </div>
            </div>

            {/* Donation Item 3 */}
            <div className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition cursor-pointer">
              <div className="flex items-center gap-4">
                <div className="bg-green-100 p-3 rounded-lg">
                  <FaHeart className="text-green-600" />
                </div>
                <div>
                  <p className="font-semibold text-gray-800">Sustentabilidade</p>
                  <p className="text-sm text-gray-600">Doação em 05/10/2025</p>
                </div>
              </div>
              <div className="text-right">
                <p className="font-bold text-gray-800">R$ 1.200,00</p>
                <p className="text-sm text-green-600">Confirmada</p>
              </div>
            </div>
          </div>

          {/* View All Button */}
          <div className="mt-6 text-center">
            <button className="text-purple-600 hover:text-purple-700 font-semibold">
              Ver todas as doações →
            </button>
          </div>
        </div>
      </main>
    </div>
  );
};

export default DashboardDoador;

