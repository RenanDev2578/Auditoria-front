import { FaArrowLeft, FaCheckCircle, FaClock, FaDownload, FaShare2 } from "react-icons/fa";

const DetalhesDoacoes = () => {
  return (
    <div className="w-full min-h-screen bg-gradient-to-br from-blue-50 to-purple-50">
      {/* Header */}
      <header className="bg-white shadow-md">
        <div className="max-w-4xl mx-auto px-6 py-4 flex items-center gap-4">
          <button className="text-purple-600 hover:text-purple-700 transition">
            <FaArrowLeft className="text-2xl" />
          </button>
          <h1 className="text-2xl font-bold text-gray-800">Detalhes da Doação</h1>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-6 py-8">
        {/* Donation Info Card */}
        <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
          <div className="flex justify-between items-start mb-6">
            <div>
              <h2 className="text-3xl font-bold text-gray-800 mb-2">
                Projeto Educação
              </h2>
              <p className="text-gray-600">Bolsas de estudo para crianças carentes</p>
            </div>
            <div className="text-right">
              <p className="text-4xl font-bold text-purple-600">R$ 500,00</p>
              <p className="text-sm text-gray-600 mt-2">Doação realizada em 15/10/2025</p>
            </div>
          </div>

          {/* Status Badge */}
          <div className="flex items-center gap-2 mb-6">
            <FaCheckCircle className="text-green-500 text-xl" />
            <span className="px-4 py-2 bg-green-100 text-green-700 rounded-full font-semibold">
              Confirmada
            </span>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-4">
            <button className="flex items-center gap-2 px-6 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition">
              <FaDownload />
              <span>Baixar Recibo</span>
            </button>
            <button className="flex items-center gap-2 px-6 py-2 border border-purple-600 text-purple-600 rounded-lg hover:bg-purple-50 transition">
              <FaShare2 />
              <span>Compartilhar</span>
            </button>
          </div>
        </div>

        {/* Timeline */}
        <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
          <h3 className="text-xl font-bold text-gray-800 mb-8">Jornada da Doação</h3>

          <div className="space-y-8">
            {/* Timeline Item 1 */}
            <div className="flex gap-6">
              <div className="flex flex-col items-center">
                <div className="w-12 h-12 rounded-full bg-green-500 flex items-center justify-center text-white">
                  <FaCheckCircle className="text-xl" />
                </div>
                <div className="w-1 h-20 bg-green-500 mt-2"></div>
              </div>
              <div className="pb-8">
                <h4 className="font-bold text-gray-800 text-lg">Doação Iniciada</h4>
                <p className="text-gray-600 text-sm mt-1">15/10/2025 às 10:30</p>
                <p className="text-gray-700 mt-3">
                  Sua doação foi registrada no sistema e aguarda confirmação de pagamento.
                </p>
              </div>
            </div>

            {/* Timeline Item 2 */}
            <div className="flex gap-6">
              <div className="flex flex-col items-center">
                <div className="w-12 h-12 rounded-full bg-green-500 flex items-center justify-center text-white">
                  <FaCheckCircle className="text-xl" />
                </div>
                <div className="w-1 h-20 bg-green-500 mt-2"></div>
              </div>
              <div className="pb-8">
                <h4 className="font-bold text-gray-800 text-lg">Pagamento Confirmado</h4>
                <p className="text-gray-600 text-sm mt-1">15/10/2025 às 10:45</p>
                <p className="text-gray-700 mt-3">
                  Seu pagamento foi processado com sucesso. ID da transação: #TRX-2025-001234
                </p>
              </div>
            </div>

            {/* Timeline Item 3 */}
            <div className="flex gap-6">
              <div className="flex flex-col items-center">
                <div className="w-12 h-12 rounded-full bg-green-500 flex items-center justify-center text-white">
                  <FaCheckCircle className="text-xl" />
                </div>
                <div className="w-1 h-20 bg-green-500 mt-2"></div>
              </div>
              <div className="pb-8">
                <h4 className="font-bold text-gray-800 text-lg">Registrado na Blockchain</h4>
                <p className="text-gray-600 text-sm mt-1">15/10/2025 às 11:00</p>
                <p className="text-gray-700 mt-3">
                  Sua doação foi registrada na blockchain pública para garantir transparência e imutabilidade.
                </p>
                <p className="text-purple-600 text-sm mt-2 font-mono">
                  Hash: 0x7f8c8d9e0f1a2b3c4d5e6f7a8b9c0d1e
                </p>
              </div>
            </div>

            {/* Timeline Item 4 */}
            <div className="flex gap-6">
              <div className="flex flex-col items-center">
                <div className="w-12 h-12 rounded-full bg-blue-500 flex items-center justify-center text-white">
                  <FaClock className="text-xl" />
                </div>
              </div>
              <div>
                <h4 className="font-bold text-gray-800 text-lg">Impacto em Andamento</h4>
                <p className="text-gray-600 text-sm mt-1">Próximas atualizações em 20/10/2025</p>
                <p className="text-gray-700 mt-3">
                  Acompanhe como sua doação está impactando vidas. Receberá atualizações sobre o progresso do projeto.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Impact Details */}
        <div className="bg-white rounded-xl shadow-lg p-8">
          <h3 className="text-xl font-bold text-gray-800 mb-6">Impacto Social</h3>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Impact Card 1 */}
            <div className="border border-gray-200 rounded-lg p-6 text-center">
              <p className="text-4xl font-bold text-purple-600 mb-2">25</p>
              <p className="text-gray-700 font-semibold">Crianças Beneficiadas</p>
              <p className="text-gray-600 text-sm mt-2">Sua doação ajuda 25 crianças</p>
            </div>

            {/* Impact Card 2 */}
            <div className="border border-gray-200 rounded-lg p-6 text-center">
              <p className="text-4xl font-bold text-blue-600 mb-2">12</p>
              <p className="text-gray-700 font-semibold">Meses de Bolsa</p>
              <p className="text-gray-600 text-sm mt-2">Cobrindo um ano letivo completo</p>
            </div>

            {/* Impact Card 3 */}
            <div className="border border-gray-200 rounded-lg p-6 text-center">
              <p className="text-4xl font-bold text-green-600 mb-2">100%</p>
              <p className="text-gray-700 font-semibold">Transparência</p>
              <p className="text-gray-600 text-sm mt-2">Registrado na blockchain</p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default DetalhesDoacoes;

